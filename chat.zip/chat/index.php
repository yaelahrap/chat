<!-- CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.7.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.7.0/firebase-database.js"></script>

<!-- JS -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->

<script>
    // Your web app's Firebase configuration
    var firebaseConfig = {
        apiKey: "AIzaSyD7WHYJUFHa2biX2bY8XIT9nMOJkBNkzMU",
        authDomain: "group-chat-test-90ee2.firebaseapp.com",
        databaseURL: "https://group-chat-test-90ee2.firebaseio.com",
        projectId: "group-chat-test-90ee2",
        storageBucket: "group-chat-test-90ee2.appspot.com",
        messagingSenderId: "1070355240944",
        appId: "1:1070355240944:web:742b9aefd803f2e2a3af35"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

    var myName = prompt("Enter your name");

    function sendMessage() {
        var message = document.getElementById("messaage").value;

        firebase.database().ref("messages").push().set({
            "sender": myName,
            "message": message
        });

        return false;
    }

    firebase.database().ref("messages").on("child_added", function(snapshot) {
        var html = "";
        // give message a unique ID
        html += "<li id='message-" + snapshot.key + "'>";
            // show delete button if send by me
            if ( snapshot.val().sender ==myName ) {
                html += "<button class='btn btn-danger' data-id='" + snapshot.key + "' onclick='deleteMessage(this);'>";
                    html += "Delete";
                html += "</button>";
            }
            html += snapshot.val().sender + ": " + snapshot.val().message;
        html += "</li>";

        document.getElementById("messages").innerHTML += html;
    });

    function deleteMessage(self) {
        // get message id
        var messageId = self.getAttribute("data-id");

        // delete message 
        firebase.database().ref("messages").child(messageId).remove();
    }

    // attach listener for delete message
    firebase.database().ref("messages").on("child_removed", function (snapshot) {
        // remove node message
        document.getElementById("message-" + snapshot.key).innerHTML = "This message has been removed";
    });
</script>

<form onsubmit="return sendMessage();">
    <div class="container">
        <div class="card my-3">
            <h5 class="card-header">Group Chat</h5>
            <div class="card-body">
                <div id="messages" class="alert alert-primary" role="alert">
                    
                </div>
                <div class="form-group">
                    <input class="form-control my-4" id="messaage" placeholder="Enter message" autocomplete="off">

                    <input class="btn btn-primary" type="submit">
                </div>
            </div>
        </div>
    </div>
</form>